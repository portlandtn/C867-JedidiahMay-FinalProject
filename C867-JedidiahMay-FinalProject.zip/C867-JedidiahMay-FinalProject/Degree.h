#pragma once

enum Degree {
	SECURITY,
	NETWORK,
	SOFTWARE
};